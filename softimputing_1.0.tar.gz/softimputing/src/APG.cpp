
#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
//[[Rcpp::depends(RcppArmadillo)]]
//' Using SOFT-IMPUTE algorithm to get the optimun matriX for nuclear norm regularization
//' 
//' @param X the observation matrix
//' @param Y the optimal matrix 
//' @return The optimal matrix Y
//' @example
//' Y =APT(X,lambda)
// [[Rcpp::export]]
arma::mat APG(arma::mat X,double lambda);
arma::mat POmega(arma::mat Y,arma::mat X);
double Funcvalue(arma::mat Y,arma::mat X,double lambda); 
arma::mat softthre(arma::mat A,double lambda);

arma::mat POmega(arma::mat Y,arma::mat X){
  int n=X.n_rows;
  int m=X.n_cols;
  for(int i=1;i<n+1;i++){
    for(int j=1;j<m+1;j++){
    if(!(X(i-1,j-1)==10000)){
    Y(i-1,j-1)=Y(i-1,j-1);
   }
    else{
    Y(i-1,j-1)=0;
   }
    }
  
  }
  return Y;
}





double Funcvalue(arma::mat Y,arma::mat X,double lambda){
  arma::mat D=POmega(Y-X,X);

  double DD=trace(D.t()*D);
  arma::vec d;
  arma::mat u;
  arma::mat v;
  svd(u,d,v,Y);
 
  double s=sum(d);
  double value=1/2*DD+lambda*s;
  return value;
  
}


double nonneg(double x){
  if(x>0){
    x=x;
  }
  else{
    x=0;
  }
  return x;
}


arma::mat softthre(arma::mat A,double lambda){
  int n=A.n_rows;
  int m=A.n_cols;
  arma::mat u;
  arma::mat v;
 arma::mat B;
  arma::vec d;
  arma::mat D(n,m,fill::zeros);
  svd(u,d,v,A);
  int n1=d.n_elem;
  for(int i=1;i<n1+1;i++)
  {
    vec vv(2);
    vv(0)=d(i-1)-lambda;
    vv(1)=0;
    D(i-1,i-1)=max(vv);
  }
  B=u*D*v.t();
  return(B);
}




arma::mat APG(arma::mat X,double lambda) {
  int n=X.n_rows;
  int m=X.n_cols;
  arma::mat Zold(n,m);
  Zold.zeros();
  arma::mat Z(n,m);
  arma::mat Znew(n,m);
  Zold=softthre(POmega(X,X)+Zold-POmega(Zold,X),lambda);
  Znew=softthre(POmega(X,X)+Zold-POmega(Zold,X),lambda);
  double eps=1e-6;
  

  while(trace((Znew-Zold).t()*(Znew-Zold))/trace(Zold.t()*Zold)>eps){
    
    Zold=Znew;
    Znew=softthre(POmega(X,X)+Zold-POmega(Zold,X),lambda);
    Znew=Znew+0.5*(Znew-Zold);
  }
    Z=Znew;
  for(int i=1; i<n+1;i++){
    for(int j=1;j<m+1;j++){
      if(Z(i-1,j-1)<0){
        Z(i-1,j-1)=0;
      }
      if(Z(i-1,j-1)>1){
        Z(i-1,j-1)=1;
      }
    }
  }
  return Z;
  }
  
  
  
 



